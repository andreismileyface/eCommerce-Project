
**<mark>Team members:</mark> Andrei Marinescu, Kofi Osel, Hawad Ahmad**
fsdfsf
<center> <h1>Our Proposal</h1> </center>

 
# Tour and travel Web application:

We will build a travel website that will allow users to book tour for a travel, provide important information to customer who wish to travel to a specific place and provide travel reviews.

  
<br />

## As of April 6 2022, we have implemented 15 features:
### Features implemented by Hawad:
- As a user, I can view trips (flights and cruises)
- As a user, I can filter trips by start and destination
- As a user, I can view the all the information of the trip
- As a user, I can access the profile of the user who sells the trip
- For security purposes, if I try to access a trip that does not exist (by manipulating the url), I get redirected to the home page
- For security purposes, if I try to access the edip or delete page of a trip that I don't own, I get redirected. So only the creator of the trip can delete or modify the trip.

### Features implemented by Andrei:
- As a user, I can contact the website
- If I'm not logged in, the contact form is disabled
- As a user, I can change my email
- I can access the home page wherever I am located on the website
- After a certain amount of inactivity, I get logged out

### Features implemented by Kofi:
- As a user, I can change my password
- As a user, I can publish a trip
- As a user, I can edit my trip
- As a user, I can delete a trip,
- As a user, I can access my profile page

  
<br />

  **Total amount of features:**
  
  <mark>30 features</mark> since we are 3 members in our team.  

  <br />
  

**The 5 different web pages will include:**

-   Home page
    

-   Flight page
    
-   Cruise page
    
-   Contact page
    
-   Shopping cart page
    
<br />

  **Estimated time for this project:**

We estimate that we will spend a total of <mark>210 hours</mark> building this product.

<mark>70 hours **per team member**.</mark>
