
**<mark>Team members:</mark> Andrei Marinescu, Kofi Osel, Hawad Ahmad**
fsdfsf
<center> <h1>Our Proposal</h1> </center>

 
### Tour and travel Web application:

We will build a travel website that will allow users to book tour for a travel, provide important information to customer who wish to travel to a specific place and provide travel reviews.

  
<br />

#### Our project will support the following stories:

**Seller section:**

1.  We can register, login, and logout (*these are not new features - they are given in class*).
    
2.  We can add and modify trips that we offer and track sales of these purchases (*3 features*).
    
3.  We can create and modify my store profile (*1 feature*).
    
4.  We can view flight detail purchases and mark them as shipped while adding tracking information (*2 features*).
    
5.  We can edit a maximum of purchases per travel option and disable the purchase of specific trips when full (*2 features*).
    
6.  We can view client service requests on sales and respond (*2 features*).
    
7.  When contacted in the contact page, we can view and respond to the user based on the email they put in (*2 features*).
    
8.  Since this is not a real web application, we will add credit card information, change their value and delete them (*3 features*).
   
<br />


**User section:**

1.  User can see the country on Google map (*2 features*)
    
2.  User can see Reviews and rating, and filter them (*3 features*)
    
3.  User can access the contact page and send a request (*1 features*)
    
4.  Users can checkout their order (*1 features*).
    
5.  User can refund their order (*1 features*)
    
6.  User can add/delete/modify quantities for products to my shopping cart (*3 features*)
    
7.  If amount in credit card is too low it will be rejected (*1 feature*)
    
8.  Users will see a countdown for discounted prices and when the time goes to 0, the amount will change to their original price (*2 features*)
    >  like in the website “Udemy”.
    
9.  Currency converter (*1 features*).
  
<br />

  **Total amount of features:**
  
  <mark>30 features</mark> since we are 3 members in our team.  

  <br />
  

**The 5 different web pages will include:**

-   Home page
    

-   Flight page
    
-   Cruise page
    
-   Contact page
    
-   Shopping cart page
    
<br />

  **Estimated time for this project:**

We estimate that we will spend a total of <mark>210 hours</mark> building this product.

<mark>70 hours **per team member**.</mark>
