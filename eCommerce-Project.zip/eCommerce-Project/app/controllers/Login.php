<?php
class Login extends Controller
{
    public function __construct()
    {
        $this->loginModel = $this->model('loginModel');
    }

    public function index()
    {
        if(!isset($_POST['login'])){
            $this->view('Login/index');
        }
        else{
            $user = $this->loginModel->getUser($_POST['Email']);
            
            if($user != null){
                $hashed_pass = $user->password_hash;
                $password = $_POST['Password'];
                if(password_verify($password,$hashed_pass)){
                    //echo '<meta http-equiv="Refresh" content="2; url=/MVC/">';
                    $this->createSession($user);
                    $data = [
                        'msg' => "Welcome, $user->email!",
                    ];
                    $this->view('Home/index',$data);
                }
                else{
                    $data = [
                        'msg' => "Password incorrect! for $user->email",
                    ];
                    $this->view('Login/index',$data);
                }
            }
            else{
                $data = [
                    'msg' => "User: ". $_POST['Email'] ." does not exists",
                ];
                $this->view('Login/index',$data);
            }
        }
    }

    /*public function newUser()
    {
        if(!isset($_POST['signup'])){
            $this->view('NewUser');
        }
        else{
            $user = $this->loginModel->getUser($_POST['Email']);
            if($user == null){
                $data = [
                    'first_name' => trim($_POST['first_name']),
                    'last_name' => trim($_POST['last_name']),
                    'email' => $_POST['email'],
                    'pass' => $_POST['password'],
                    'pass_verify' => $_POST['verify_password'],
                    'password_hash' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                    'firstName_error' => '',
                    'lastName_error' => '',
                    'email_error' => '',
                    'password_error' => '',
                    'password_match_error' => '',
                    'password_len_error' => '',
                    'msg' => ''
                ];
                if($this->validateData($data)){
                    if($this->loginModel->createUser($data)){
                        echo 'Please wait creating the account for '.trim($_POST['email']);
                        echo '<meta http-equiv="Refresh" content="2; url=/eCommerce-Project/Login/">';
                 }
                } 
            }
            else{
                $data = [
                    'msg' => "User: ". $_POST['first_name'] ." already exists",
                ];
                $this->view('Login/newUser',$data);
            }
            
        }
    }

    public function validateData($data){
        if(empty($data['first_name'])){
            $data['firstName_error'] = 'First name can not be empty';
        }
        if (!filter_var($data['last_name'])) {
            $data['lastName_error'] = 'Please check your email and try again';
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $data['email_error'] = 'Please check your email and try again';
        }
        if(strlen($data['pass']) < 6){
            $data['password_len_error'] = 'Password can not be less than 6 characters';
        }
        if($data['pass'] != $data['pass_verify']){
            $data['password_match_error'] = 'Password does not match';
        }

        if(empty($data['firstName_error']) && empty($data['password_error']) && empty($data['password_len_error']) && empty($data['password_match_error'])){
            return true;
        }
        else{
            $this->view('Login/newUser',$data);
        }
    }*/

    public function createSession($user){
        echo '<meta http-equiv="Refresh" content="0; url=/eCommerce-Project/">';
        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_email'] = $user->email;
        $_SESSION['user_first_name'] = $user->first_name;
        
    }

    public function logout(){
        unset($_SESSION['user_id']);
        session_destroy();
        echo '<meta http-equiv="Refresh" content="1; url=/eCommerce-Project/">';
    }
}
