<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title> Travel Tsunami </title>
    <link rel="stylesheet" href="public/css/Header.css">
    <link rel="stylesheet" href="public/css/style.css">

</head>

<body>
    <div class="header">
        <h1>Travel Tsunami</h1>
        <p>Experience The Fullness Of Traveling</p>
        <a href="Contact" class="contact-btn"> Contact Us For More Information </a>
    </div>

    <div class="navigation-top">
        <a href="Author/signin" class="nav-links">Sign In</a>
        <a href="Home" style="float:left; font-weight: bold;">Travel Tsunami</a>
        <a href="Contact" class="nav-links" style="float:left">Contact</a>
        <a href="Cruise" class="nav-links" style="float:left">Cruises</a>
        <a href="Flight" class="nav-links" style="float:left">Flights</a>
    </div>