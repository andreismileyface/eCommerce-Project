<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title> Travel Tsunami </title>
    <link rel="stylesheet" href="public/css/Header.css">
    <link rel="stylesheet" href="public/css/style.css">

</head>

<body>
    <div class="header">
        <h1>Travel Tsunami</h1>
        <p>Experience The Fullness Of Traveling</p>
        <a href="Contact" class="contact-btn"> Contact Us For More Information </a>
    </div>

    <div class="navigation-top">
        <a href="Home" style="float:left; font-weight: bold;">Travel Tsunami</a>
        <a href="Contact" class="nav-links" style="float:left">Contact</a>
        <a href="Cruise" class="nav-links" style="float:left">Cruises</a>
        <a href="Flight" class="nav-links" style="float:left">Flights</a>

        <?php
    if (isLoggedIn()) {
      echo '<a class="nav-link" href="Login/logout"><i class="fa-solid fa-sign-out"></i> Logout  '. $_SESSION['user_first_name'].'</a>';
    } 
    else {
      echo '<a class="nav-link" href="Login/NewUser"><i class="fa-solid fa-user-plus"></i> Sign Up</a>
            <a class="nav-link" href="Login/"><i class="fa-solid fa-user-plus"></i> Login</a>';
    }
    ?>

    </div>