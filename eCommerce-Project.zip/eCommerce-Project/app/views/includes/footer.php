<div class="footer">





    <div class="row">
        <div class="column">
            <nav class="vertical">
                <a>TRAVEL TSUNAMI</a>
                <p> Book your flights, cruises
                    today and enjoy your traveling
                    plan with your friends, family
                    or even both. Make sure to invite
                    someone with you!
                </p>

            </nav>
        </div>


        <div class="column">
            <nav class="vertical">

                <a>BOOK</a>
                <br>
                <br>
                <span>
                    <a href="Flight" target="_self">Plane</a>
                </span>
                <br>
                <span>
                    <a href="Cruise" target="_self">Cruise</a>
                </span>
                <br>

            </nav>

        </div>

        <div class="column">
            <nav class="vertical">

                <a>CONTACT</a>
                <br>
                <br>
                <span>
                    <a href="Contact" target="_self">Contact</a>
                </span>

            </nav>

        </div>

        <div class="column">
            <section>Travel Tsunami &copy; 2021 English (CA)</section>

        </div>

    </div>
    <script src="<?php echo URLROOT; ?>/javascript/main.js"></script>



    </body>

    </html>